#!/usr/bin/env python3
"""Rebuild H-CSMO ablation summary from frozen per-run results; no simulations."""
import argparse, collections, csv, hashlib, json, math
from pathlib import Path
from statistics import mean, stdev

HERE = Path(__file__).resolve().parent.parent
METRICS = [
    'carbon_emissions_g','total_energy_wh','makespan_s',
    'deadline_miss_ratio','mean_response_time_s','p95_response_time_s',
    'migration_volume_gib','migration_count',
]

def load_csv(path):
    with path.open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',default='reconstructed_ablation.csv')
    args=p.parse_args()
    rows=load_csv(HERE/'evidence/140_run_level.csv')
    assert len(rows)==140, f'Unexpected run count: {len(rows)}'
    assert {r['status'] for r in rows}=={'PASS'},'Some runs were not PASS'
    groups=collections.defaultdict(list)
    unique=set()
    for r in rows:
        key=(r['dataset'],r['method'],r['seed'])
        assert key not in unique, f'Duplicate combination: {key}'
        unique.add(key)
        groups[(r['dataset'],r['method'])].append(r)
    assert len(groups)==14
    assert all(len(v)==10 for v in groups.values())
    reference={(r['dataset'],r['method']):r for r in load_csv(HERE/'evidence/140_group_reference.csv')}
    differences=[];out=[]
    for key,rr in sorted(groups.items()):
        record={'dataset':key[0],'method':key[1],'n_seeds':len(rr)}
        for metric in METRICS:
            values=[float(r[metric]) for r in rr]
            observed_mean=mean(values); observed_std=stdev(values)
            record[f'{metric}__mean']=f'{observed_mean:.12g}'
            record[f'{metric}__std']=f'{observed_std:.12g}'
            for suffix,actual in [('mean',observed_mean),('std',observed_std)]:
                expected=float(reference[key][f'{metric}__{suffix}'])
                if not math.isclose(actual,expected,rel_tol=1e-10,abs_tol=1e-8):
                    differences.append((key,metric,suffix,actual,expected))
        out.append(record)
    assert not differences,f'Mismatches against frozen group output: {differences[:8]}'
    dest=Path(args.out);dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(out[0]));writer.writeheader();writer.writerows(out)
    print(f'PASS: 140 PASS runs, 14 dataset-method groups, 10 seeds/group, '
          f'{len(METRICS)} metrics, means+sample SD match frozen outputs.')
    print('Wrote:', dest)
    print('NOTE: This verifies archived summary statistics; it does not run H-CSMO.')

if __name__=='__main__': main()
