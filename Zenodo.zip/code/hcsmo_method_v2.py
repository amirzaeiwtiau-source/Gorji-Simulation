
from __future__ import annotations

from dataclasses import dataclass
import itertools
import math

import numpy as np
import pandas as pd


EPSILON = 1e-12

METHOD_VERSION = "hcsmo-v2"

INDEX_TERM = {
    0: "low",
    1: "medium",
    2: "high",
}


@dataclass(frozen=True)
class ContextStateV2:
    """
    Runtime context for H-CSMO v2.

    eta
        Normalized positive carbon-intensity trend.

    delta
        Deadline pressure.

    mu
        Migration/disruption pressure.

    mu is intentionally NOT described as measured
    network congestion.
    """

    eta: float
    delta: float
    mu: float

    eta_max: float
    migration_volume_limit_gib: float
    previous_cycle_migration_volume_gib: float
    interval_start_s: float


@dataclass(frozen=True)
class FuzzyDecisionV2:
    carbon_weight: float
    makespan_weight: float
    energy_weight: float
    migration_weight: float

    alpha: float
    beta: float

    rho: float

    active_rule_count: int
    maximum_rule_strength: float

    def weights(self) -> np.ndarray:
        return np.array(
            [
                self.carbon_weight,
                self.makespan_weight,
                self.energy_weight,
                self.migration_weight,
            ],
            dtype=float,
        )


def triangular_membership(
    x: np.ndarray | float,
    a: float,
    b: float,
    c: float,
) -> np.ndarray:
    """
    Same triangular/shoulder semantics as the
    validated v1.1 fuzzy controller.
    """

    values = np.asarray(
        x,
        dtype=float,
    )

    result = np.zeros_like(
        values,
        dtype=float,
    )

    if a == b:
        result[
            values <= b
        ] = 1.0

        mask = (
            (values > b)
            & (values < c)
        )

        result[mask] = (
            c - values[mask]
        ) / (
            c - b
        )

    elif b == c:
        result[
            values >= b
        ] = 1.0

        mask = (
            (values > a)
            & (values < b)
        )

        result[mask] = (
            values[mask] - a
        ) / (
            b - a
        )

    else:
        left_mask = (
            (values > a)
            & (values < b)
        )

        result[left_mask] = (
            values[left_mask] - a
        ) / (
            b - a
        )

        result[
            np.isclose(
                values,
                b,
                rtol=0.0,
                atol=1e-15,
            )
        ] = 1.0

        right_mask = (
            (values > b)
            & (values < c)
        )

        result[right_mask] = (
            c - values[right_mask]
        ) / (
            c - b
        )

    return np.clip(
        result,
        0.0,
        1.0,
    )


def scalar_membership(
    value: float,
    parameters: tuple[
        float,
        float,
        float,
    ],
) -> float:
    return float(
        triangular_membership(
            np.array(
                [value],
                dtype=float,
            ),
            *parameters,
        )[0]
    )


def clipped_level(
    value: int,
) -> int:
    return int(
        np.clip(
            int(value),
            0,
            2,
        )
    )


def generate_rule_table_v2() -> pd.DataFrame:
    """
    Preserve the six validated v1.1 consequents,
    replacing nu with the correctly named mu,
    and add one new rho consequent.

    rho controls the admissible schedule-change
    neighborhood:
      tight      -> small
      moderate   -> medium
      permissive -> large
    """

    rows = []
    rule_id = 0

    for (
        eta_level,
        delta_level,
        mu_level,
    ) in itertools.product(
        range(3),
        repeat=3,
    ):
        rule_id += 1

        # ---- Existing v1.1 semantics, unchanged ----

        carbon_level = clipped_level(
            eta_level
            - int(
                delta_level == 2
            )
            - int(
                mu_level == 2
            )
        )

        makespan_level = clipped_level(
            delta_level
        )

        energy_level = clipped_level(
            2 - delta_level
        )

        migration_level = clipped_level(
            mu_level
        )

        alpha_level = clipped_level(
            delta_level
            + mu_level
            - eta_level
        )

        beta_level = clipped_level(
            2 - alpha_level
        )

        # ---- New v2 supervisory search-region policy ----
        #
        # Priority:
        # 1. High disruption => tighten.
        # 2. Medium disruption + high deadline => tighten.
        # 3. Low disruption + high carbon and non-high
        #    deadline => permit broader reassignment.
        # 4. Low disruption + high deadline => moderate.
        # 5. Remaining states => moderate.

        if mu_level == 2:
            rho_priority = "tight"

        elif (
            mu_level == 1
            and delta_level == 2
        ):
            rho_priority = "tight"

        elif (
            mu_level == 0
            and eta_level == 2
            and delta_level in {0, 1}
        ):
            rho_priority = "permissive"

        elif (
            mu_level == 0
            and delta_level == 2
        ):
            rho_priority = "moderate"

        else:
            rho_priority = "moderate"

        rows.append(
            {
                "rule_id": rule_id,

                "eta": INDEX_TERM[
                    eta_level
                ],

                "delta": INDEX_TERM[
                    delta_level
                ],

                "mu": INDEX_TERM[
                    mu_level
                ],

                "carbon_priority": INDEX_TERM[
                    carbon_level
                ],

                "makespan_priority": INDEX_TERM[
                    makespan_level
                ],

                "energy_priority": INDEX_TERM[
                    energy_level
                ],

                "migration_priority": INDEX_TERM[
                    migration_level
                ],

                "alpha_priority": INDEX_TERM[
                    alpha_level
                ],

                "beta_priority": INDEX_TERM[
                    beta_level
                ],

                "rho_priority": rho_priority,
            }
        )

    return pd.DataFrame(
        rows
    )




def infer_monotone_rho_v2(
    controller,
    eta: float,
    delta: float,
    mu: float,
) -> float:
    """
    Monotonic fuzzy interpolation for rho only.

    The existing 27 linguistic rules are retained.

    The three existing rho fuzzy sets are represented by
    their own centroids. Product firing strengths produce
    multilinear interpolation over the complete 3x3x3 rule
    lattice.

    Because, for every fixed eta/delta linguistic pair,
    rho consequents are non-increasing from
    mu=low -> medium -> high, rho is consequently
    non-increasing in continuous mu.

    All other controller outputs continue to use the
    original Mamdani min/max/centroid inference.
    """

    eta_memberships = (
        controller.fuzzify(
            eta
        )
    )

    delta_memberships = (
        controller.fuzzify(
            delta
        )
    )

    mu_memberships = (
        controller.fuzzify(
            mu
        )
    )

    singleton_values = {
        term: float(
            controller._centroid(
                membership
            )
        )
        for (
            term,
            membership,
        ) in (
            controller
            .rho_output_memberships
            .items()
        )
    }

    if not (
        singleton_values["tight"]
        <= singleton_values["moderate"]
        <= singleton_values["permissive"]
    ):
        raise RuntimeError(
            "rho linguistic representatives are not ordered."
        )

    numerator = 0.0
    denominator = 0.0

    for rule in controller.rules.itertuples(
        index=False
    ):

        firing_strength = (
            float(
                eta_memberships[
                    rule.eta
                ]
            )
            * float(
                delta_memberships[
                    rule.delta
                ]
            )
            * float(
                mu_memberships[
                    rule.mu
                ]
            )
        )

        if firing_strength <= EPSILON:
            continue

        numerator += (
            firing_strength
            * singleton_values[
                rule.rho_priority
            ]
        )

        denominator += firing_strength

    if denominator <= EPSILON:
        raise RuntimeError(
            "rho fuzzy interpolation has zero "
            "total firing strength."
        )

    return float(
        np.clip(
            numerator
            / denominator,
            0.0,
            1.0,
        )
    )

class AlignedMamdaniControllerV2:
    """
    H-CSMO v2 fuzzy supervisory controller.

    Inputs:
        eta, delta, mu

    Outputs:
        objective weights,
        alpha/beta SMO dynamics,
        rho schedule-change budget.
    """

    def __init__(
        self,
        universe_points: int = 1001,
    ) -> None:

        if int(universe_points) < 3:
            raise ValueError(
                "universe_points must be >= 3."
            )

        # Existing v1.1 low/medium/high semantics.
        self.membership_parameters = {
            "low": (
                0.0,
                0.0,
                0.5,
            ),
            "medium": (
                0.0,
                0.5,
                1.0,
            ),
            "high": (
                0.5,
                1.0,
                1.0,
            ),
        }

        # Explicit reviewer-facing meaning for rho.
        self.rho_membership_parameters = {
            "tight": (
                0.0,
                0.0,
                0.5,
            ),
            "moderate": (
                0.0,
                0.5,
                1.0,
            ),
            "permissive": (
                0.5,
                1.0,
                1.0,
            ),
        }

        self.universe = np.linspace(
            0.0,
            1.0,
            int(universe_points),
        )

        self.priority_output_memberships = {
            term: triangular_membership(
                self.universe,
                *parameters,
            )
            for term, parameters
            in self.membership_parameters.items()
        }

        self.rho_output_memberships = {
            term: triangular_membership(
                self.universe,
                *parameters,
            )
            for term, parameters
            in self.rho_membership_parameters.items()
        }

        self.rules = (
            generate_rule_table_v2()
        )

        if len(
            self.rules
        ) != 27:
            raise RuntimeError(
                "H-CSMO v2 requires exactly 27 fuzzy rules."
            )

    @staticmethod
    def _validate_input(
        name: str,
        value: float,
    ) -> float:
        numeric = float(
            value
        )

        if (
            not math.isfinite(
                numeric
            )
            or numeric < 0.0
            or numeric > 1.0
        ):
            raise ValueError(
                f"{name} must be finite and in [0,1]."
            )

        return numeric

    def fuzzify(
        self,
        value: float,
    ) -> dict[str, float]:
        numeric = self._validate_input(
            "input",
            value,
        )

        return {
            term: scalar_membership(
                numeric,
                parameters,
            )
            for term, parameters
            in self.membership_parameters.items()
        }

    def _centroid(
        self,
        membership: np.ndarray,
    ) -> float:
        area = float(
            np.trapezoid(
                membership,
                self.universe,
            )
        )

        if area <= EPSILON:
            raise RuntimeError(
                "Aggregated output has zero area."
            )

        moment = float(
            np.trapezoid(
                self.universe
                * membership,
                self.universe,
            )
        )

        return (
            moment / area
        )

    def infer(
        self,
        eta: float,
        delta: float,
        mu: float,
    ) -> FuzzyDecisionV2:

        eta_value = self._validate_input(
            "eta",
            eta,
        )

        delta_value = self._validate_input(
            "delta",
            delta,
        )

        mu_value = self._validate_input(
            "mu",
            mu,
        )

        memberships = {
            "eta": self.fuzzify(
                eta_value
            ),
            "delta": self.fuzzify(
                delta_value
            ),
            "mu": self.fuzzify(
                mu_value
            ),
        }

        priority_output_names = [
            "carbon_priority",
            "makespan_priority",
            "energy_priority",
            "migration_priority",
            "alpha_priority",
            "beta_priority",
        ]

        aggregated = {
            name: np.zeros_like(
                self.universe,
                dtype=float,
            )
            for name in priority_output_names
        }

        aggregated[
            "rho_priority"
        ] = np.zeros_like(
            self.universe,
            dtype=float,
        )

        active_rule_count = 0
        maximum_rule_strength = 0.0

        for rule in self.rules.itertuples(
            index=False
        ):
            strength = min(
                memberships[
                    "eta"
                ][rule.eta],

                memberships[
                    "delta"
                ][rule.delta],

                memberships[
                    "mu"
                ][rule.mu],
            )

            if strength <= 0.0:
                continue

            active_rule_count += 1

            maximum_rule_strength = max(
                maximum_rule_strength,
                strength,
            )

            # Existing outputs.
            for output_name in priority_output_names:
                term = getattr(
                    rule,
                    output_name,
                )

                clipped = np.minimum(
                    strength,
                    self.priority_output_memberships[
                        term
                    ],
                )

                aggregated[
                    output_name
                ] = np.maximum(
                    aggregated[
                        output_name
                    ],
                    clipped,
                )

            # New rho output.
            rho_term = rule.rho_priority

            rho_clipped = np.minimum(
                strength,
                self.rho_output_memberships[
                    rho_term
                ],
            )

            aggregated[
                "rho_priority"
            ] = np.maximum(
                aggregated[
                    "rho_priority"
                ],
                rho_clipped,
            )

        crisp = {
            name: self._centroid(
                membership
            )
            for name, membership
            in aggregated.items()
        }

        raw_weights = np.array(
            [
                crisp[
                    "carbon_priority"
                ],
                crisp[
                    "makespan_priority"
                ],
                crisp[
                    "energy_priority"
                ],
                crisp[
                    "migration_priority"
                ],
            ],
            dtype=float,
        )

        weight_sum = float(
            raw_weights.sum()
        )

        if weight_sum <= EPSILON:
            raise RuntimeError(
                "The objective-priority sum is zero."
            )

        weights = (
            raw_weights
            / weight_sum
        )

        raw_alpha = float(
            np.clip(
                crisp[
                    "alpha_priority"
                ],
                0.0,
                1.0,
            )
        )

        raw_beta = float(
            np.clip(
                crisp[
                    "beta_priority"
                ],
                0.0,
                1.0,
            )
        )

        parameter_sum = (
            raw_alpha
            + raw_beta
        )

        if parameter_sum <= EPSILON:
            alpha = 0.5
            beta = 0.5

        else:
            alpha = (
                raw_alpha
                / parameter_sum
            )

            beta = (
                raw_beta
                / parameter_sum
            )

        rho = infer_monotone_rho_v2(
            self,
            eta_value,
            delta_value,
            mu_value,
        )

        return FuzzyDecisionV2(
            carbon_weight=float(
                weights[0]
            ),

            makespan_weight=float(
                weights[1]
            ),

            energy_weight=float(
                weights[2]
            ),

            migration_weight=float(
                weights[3]
            ),

            alpha=float(
                np.clip(
                    alpha,
                    0.0,
                    1.0,
                )
            ),

            beta=float(
                np.clip(
                    beta,
                    0.0,
                    1.0,
                )
            ),

            rho=rho,

            active_rule_count=int(
                active_rule_count
            ),

            maximum_rule_strength=float(
                maximum_rule_strength
            ),
        )



class ContextSignalComputerV2:
    """
    H-CSMO v2 context computation.

    eta and delta preserve the validated v1.1
    rolling-context semantics.

    mu is the corrected name for the third signal:
    prior migration/disruption pressure, not measured
    network congestion.
    """

    def __init__(
        self,
        carbon,
        adaptation_horizon_seconds: float,
        normalization_window_seconds: float,
        deadline_horizon_multiplier: float,
    ) -> None:

        self.carbon = carbon

        self.adaptation_horizon_seconds = float(
            adaptation_horizon_seconds
        )

        self.normalization_window_seconds = float(
            normalization_window_seconds
        )

        self.deadline_horizon_multiplier = float(
            deadline_horizon_multiplier
        )

        if (
            self.adaptation_horizon_seconds <= 0.0
            or self.normalization_window_seconds <= 0.0
            or self.deadline_horizon_multiplier <= 0.0
        ):
            raise ValueError(
                "Context horizons must be positive."
            )

        self.eta_max = self._derive_eta_max()


    def _mean_carbon(
        self,
        time_s: float,
    ) -> float:

        return float(
            np.mean(
                [
                    self.carbon.intensity(
                        region_id,
                        time_s,
                    )
                    for region_id in sorted(
                        self.carbon.values
                    )
                ]
            )
        )


    def _derive_eta_max(
        self,
    ) -> float:

        cycle = float(
            self.carbon.cycle_seconds
        )

        step = float(
            self.adaptation_horizon_seconds
        )

        sample_times = np.arange(
            0.0,
            cycle,
            step,
            dtype=float,
        )

        relative_changes = []

        for current_time in sample_times:

            previous_time = (
                current_time
                - step
            )

            previous_mean = self._mean_carbon(
                previous_time
            )

            current_mean = self._mean_carbon(
                current_time
            )

            relative_change = (
                current_mean
                - previous_mean
            ) / max(
                previous_mean,
                EPSILON,
            )

            # Preserve v1.1 semantics:
            # only positive carbon trends contribute
            # to eta normalization.
            if relative_change > 0.0:
                relative_changes.append(
                    relative_change
                )

        if not relative_changes:
            return 1.0

        return max(
            max(
                relative_changes
            ),
            EPSILON,
        )


    @staticmethod
    def _migration_pressure(
        previous_cycle_migration_volume_gib: float,
        migration_volume_limit_gib: float,
    ) -> float:

        previous = float(
            previous_cycle_migration_volume_gib
        )

        limit = float(
            migration_volume_limit_gib
        )

        if (
            not math.isfinite(limit)
            or limit <= 0.0
        ):
            return 0.0

        if not math.isfinite(
            previous
        ):
            raise ValueError(
                "previous_cycle_migration_volume_gib "
                "must be finite."
            )

        return float(
            np.clip(
                previous / limit,
                0.0,
                1.0,
            )
        )


    def compute(
        self,
        tasks: pd.DataFrame,
        interval_start_s: float,
        previous_cycle_migration_volume_gib: float,
        migration_volume_limit_gib: float,
    ) -> ContextStateV2:

        interval_start = float(
            interval_start_s
        )

        if not math.isfinite(
            interval_start
        ):
            raise ValueError(
                "interval_start_s must be finite."
            )

        # ----------------------------------------------------
        # eta — preserve validated v1.1 definition
        # ----------------------------------------------------

        previous_mean = self._mean_carbon(
            interval_start
            - self.adaptation_horizon_seconds
        )

        current_mean = self._mean_carbon(
            interval_start
        )

        raw_relative_trend = (
            current_mean
            - previous_mean
        ) / max(
            previous_mean,
            EPSILON,
        )

        eta = float(
            np.clip(
                raw_relative_trend
                / self.eta_max,
                0.0,
                1.0,
            )
        )

        # ----------------------------------------------------
        # delta — preserve validated v1.1 definition
        # ----------------------------------------------------

        near_deadline_horizon = (
            self.deadline_horizon_multiplier
            * self.adaptation_horizon_seconds
        )

        if "deadline_offset_s" not in tasks.columns:
            raise ValueError(
                "tasks must contain deadline_offset_s."
            )

        deadline_offsets = tasks[
            "deadline_offset_s"
        ].to_numpy(
            dtype=float
        )

        near_deadline = (
            deadline_offsets
            - interval_start
            <= near_deadline_horizon
        )

        delta = float(
            near_deadline.mean()
            if len(
                near_deadline
            ) > 0
            else 0.0
        )

        # ----------------------------------------------------
        # mu — corrected migration/disruption pressure
        # ----------------------------------------------------

        mu = self._migration_pressure(
            previous_cycle_migration_volume_gib=(
                previous_cycle_migration_volume_gib
            ),
            migration_volume_limit_gib=(
                migration_volume_limit_gib
            ),
        )

        return ContextStateV2(
            eta=eta,
            delta=delta,
            mu=mu,

            eta_max=float(
                self.eta_max
            ),

            migration_volume_limit_gib=float(
                migration_volume_limit_gib
            ),

            previous_cycle_migration_volume_gib=float(
                previous_cycle_migration_volume_gib
            ),

            interval_start_s=interval_start,
        )
