
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
from typing import Iterable

import numpy as np
import pandas as pd


EPSILON = 1e-12


@dataclass(frozen=True)
class Reservation:
    task_id: str
    start_s: float
    finish_s: float
    cpu: float
    memory: float


class CarbonSeries:
    def __init__(
        self,
        frame: pd.DataFrame,
        interval_seconds: float = 1800.0,
        cycle_seconds: float = 604800.0,
    ) -> None:
        required = {
            "region_id",
            "slot_index",
            "forecast_gco2_per_kwh",
        }
        missing = required - set(frame.columns)

        if missing:
            raise ValueError(
                f"Carbon frame missing columns: {sorted(missing)}"
            )

        self.interval_seconds = float(interval_seconds)
        self.cycle_seconds = float(cycle_seconds)
        self.values: dict[int, np.ndarray] = {}

        for region_id, region_frame in frame.groupby("region_id"):
            ordered = region_frame.sort_values("slot_index")
            values = ordered[
                "forecast_gco2_per_kwh"
            ].to_numpy(dtype=float)

            if len(values) == 0:
                raise ValueError("Empty carbon region.")

            if not np.isfinite(values).all():
                raise ValueError("Non-finite carbon value.")

            if (values < 0).any():
                raise ValueError("Negative carbon value.")

            self.values[int(region_id)] = values

        if len(self.values) != 6:
            raise ValueError("Carbon model requires six regions.")

    def intensity(
        self,
        region_id: int,
        time_s: float,
    ) -> float:
        values = self.values[int(region_id)]
        wrapped = float(time_s) % self.cycle_seconds
        slot = int(
            math.floor(
                wrapped / self.interval_seconds
            )
        ) % len(values)
        return float(values[slot])

    def slot_boundaries(
        self,
        start_s: float,
        finish_s: float,
    ) -> list[float]:
        if finish_s <= start_s:
            return []

        first = (
            math.floor(
                start_s / self.interval_seconds
            ) + 1
        ) * self.interval_seconds

        boundaries = []
        current = first

        while current < finish_s - EPSILON:
            boundaries.append(float(current))
            current += self.interval_seconds

        return boundaries


class NetworkModel:
    def __init__(self, frame: pd.DataFrame) -> None:
        required = {
            "source_region_id",
            "destination_region_id",
            "base_round_trip_latency_ms",
            "bandwidth_gbps",
            "jitter_min_fraction",
            "jitter_max_fraction",
            "transfer_energy_wh_per_gib",
        }
        missing = required - set(frame.columns)

        if missing:
            raise ValueError(
                f"Network frame missing columns: {sorted(missing)}"
            )

        self.links: dict[tuple[int, int], dict[str, float]] = {}

        for row in frame.itertuples(index=False):
            key = (
                int(row.source_region_id),
                int(row.destination_region_id),
            )
            self.links[key] = {
                "rtt_ms": float(
                    row.base_round_trip_latency_ms
                ),
                "bandwidth_gbps": float(
                    row.bandwidth_gbps
                ),
                "jitter_min": float(
                    row.jitter_min_fraction
                ),
                "jitter_max": float(
                    row.jitter_max_fraction
                ),
                "energy_wh_per_gib": float(
                    row.transfer_energy_wh_per_gib
                ),
            }

        if len(self.links) != 36:
            raise ValueError("Network model requires 36 links.")

    @staticmethod
    def deterministic_uniform(
        key: str,
        seed: int,
    ) -> float:
        digest = hashlib.sha256(
            f"{seed}|{key}".encode("utf-8")
        ).digest()
        integer = int.from_bytes(
            digest[:8],
            byteorder="big",
            signed=False,
        )
        return integer / float(2**64 - 1)

    def link(
        self,
        source_region: int,
        destination_region: int,
    ) -> dict[str, float]:
        return self.links[
            (int(source_region), int(destination_region))
        ]

    def jitter_fraction(
        self,
        source_region: int,
        destination_region: int,
        key: str,
        seed: int,
    ) -> float:
        link = self.link(
            source_region,
            destination_region,
        )

        if source_region == destination_region:
            return 0.0

        unit = self.deterministic_uniform(
            key=key,
            seed=seed,
        )

        return (
            link["jitter_min"]
            + unit
            * (
                link["jitter_max"]
                - link["jitter_min"]
            )
        )

    def dispatch_delay_s(
        self,
        source_region: int,
        destination_region: int,
        key: str,
        seed: int,
    ) -> float:
        link = self.link(
            source_region,
            destination_region,
        )
        jitter = self.jitter_fraction(
            source_region,
            destination_region,
            key,
            seed,
        )

        one_way_s = (
            0.5 * link["rtt_ms"] / 1000.0
        )

        return one_way_s * (1.0 + jitter)

    def migration_cost(
        self,
        source_region: int,
        destination_region: int,
        state_mib: float,
        time_s: float,
        carbon: CarbonSeries,
        key: str,
        seed: int,
    ) -> dict[str, float]:
        if state_mib < 0:
            raise ValueError("state_mib must be nonnegative.")

        if source_region == destination_region:
            return {
                "migration_time_s": 0.0,
                "migration_energy_wh": 0.0,
                "migration_emissions_g": 0.0,
            }

        link = self.link(
            source_region,
            destination_region,
        )

        jitter = self.jitter_fraction(
            source_region,
            destination_region,
            key,
            seed,
        )

        state_gib = float(state_mib) / 1024.0
        state_gigabits = state_gib * 8.0

        transfer_s = (
            state_gigabits
            / link["bandwidth_gbps"]
        )

        control_s = (
            link["rtt_ms"]
            / 1000.0
            * (1.0 + jitter)
        )

        migration_time_s = transfer_s + control_s

        migration_energy_wh = (
            state_gib
            * link["energy_wh_per_gib"]
        )

        average_intensity = 0.5 * (
            carbon.intensity(
                source_region,
                time_s,
            )
            + carbon.intensity(
                destination_region,
                time_s,
            )
        )

        migration_emissions_g = (
            migration_energy_wh
            / 1000.0
            * average_intensity
        )

        return {
            "migration_time_s": float(
                migration_time_s
            ),
            "migration_energy_wh": float(
                migration_energy_wh
            ),
            "migration_emissions_g": float(
                migration_emissions_g
            ),
        }


def interval_is_feasible(
    reservations: list[Reservation],
    start_s: float,
    finish_s: float,
    demand_cpu: float,
    demand_memory: float,
    cpu_capacity: float,
    memory_capacity: float,
) -> bool:
    if finish_s <= start_s:
        return False

    event_points = {
        float(start_s),
        float(finish_s),
    }

    for reservation in reservations:
        if (
            reservation.finish_s <= start_s
            or reservation.start_s >= finish_s
        ):
            continue

        event_points.add(
            max(
                float(start_s),
                reservation.start_s,
            )
        )
        event_points.add(
            min(
                float(finish_s),
                reservation.finish_s,
            )
        )

    ordered = sorted(event_points)

    for left, right in zip(
        ordered[:-1],
        ordered[1:],
    ):
        if right <= left + EPSILON:
            continue

        midpoint = 0.5 * (left + right)

        active_cpu = 0.0
        active_memory = 0.0

        for reservation in reservations:
            if (
                reservation.start_s
                <= midpoint
                < reservation.finish_s
            ):
                active_cpu += reservation.cpu
                active_memory += reservation.memory

        if (
            active_cpu + demand_cpu
            > cpu_capacity + 1e-9
        ):
            return False

        if (
            active_memory + demand_memory
            > memory_capacity + 1e-9
        ):
            return False

    return True


def earliest_feasible_start(
    reservations: list[Reservation],
    release_s: float,
    duration_s: float,
    demand_cpu: float,
    demand_memory: float,
    cpu_capacity: float,
    memory_capacity: float,
) -> float:
    if duration_s <= 0:
        raise ValueError("duration_s must be positive.")

    if demand_cpu <= 0:
        raise ValueError("demand_cpu must be positive.")

    if demand_memory < 0:
        raise ValueError(
            "demand_memory must be nonnegative."
        )

    if demand_cpu > cpu_capacity + 1e-9:
        raise ValueError("CPU demand exceeds node capacity.")

    if demand_memory > memory_capacity + 1e-9:
        raise ValueError(
            "Memory demand exceeds node capacity."
        )

    candidates = {float(release_s)}

    for reservation in reservations:
        if reservation.finish_s >= release_s:
            candidates.add(
                float(reservation.finish_s)
            )

    for candidate in sorted(candidates):
        finish = candidate + duration_s

        if interval_is_feasible(
            reservations=reservations,
            start_s=candidate,
            finish_s=finish,
            demand_cpu=demand_cpu,
            demand_memory=demand_memory,
            cpu_capacity=cpu_capacity,
            memory_capacity=memory_capacity,
        ):
            return float(candidate)

    latest_finish = max(
        [
            float(release_s),
            *[
                reservation.finish_s
                for reservation in reservations
            ],
        ]
    )

    return float(latest_finish)


def task_runtime_s(
    observed_cpu_work: float,
    requested_cpu: float,
    node_type: str,
    speed_factors: dict[str, float],
) -> float:
    work = float(observed_cpu_work)
    demand = float(requested_cpu)

    if work <= 0:
        raise ValueError(
            "observed_cpu_work must be positive."
        )

    if demand <= 0:
        raise ValueError(
            "requested_cpu must be positive."
        )

    speed = float(speed_factors[node_type])

    if speed <= 0:
        raise ValueError(
            "node speed factor must be positive."
        )

    return work / (demand * speed)


def build_schedule(
    tasks: pd.DataFrame,
    nodes: pd.DataFrame,
    carbon: CarbonSeries,
    network: NetworkModel,
    speed_factors: dict[str, float],
    seed: int = 42,
) -> tuple[pd.DataFrame, dict[str, list[Reservation]]]:
    required_task_columns = {
        "dataset",
        "source_item_id",
        "nested_rank",
        "arrival_offset_s",
        "deadline_offset_s",
        "initial_region_id",
        "observed_cpu_work",
        "requested_cpu",
        "requested_memory",
        "migration_state_mib",
    }

    missing_tasks = (
        required_task_columns
        - set(tasks.columns)
    )

    if missing_tasks:
        raise ValueError(
            f"Task columns missing: {sorted(missing_tasks)}"
        )

    required_node_columns = {
        "node_id",
        "region_id",
        "node_type",
        "cpu_capacity",
        "memory_capacity",
        "idle_power_w",
        "peak_power_w",
        "regional_pue",
    }

    missing_nodes = (
        required_node_columns
        - set(nodes.columns)
    )

    if missing_nodes:
        raise ValueError(
            f"Node columns missing: {sorted(missing_nodes)}"
        )

    nodes_ordered = nodes.sort_values(
        "node_id"
    ).reset_index(drop=True)

    reservations: dict[
        str,
        list[Reservation],
    ] = {
        str(node_id): []
        for node_id in nodes_ordered["node_id"]
    }

    scheduled_rows = []

    ordered_tasks = tasks.sort_values(
        [
            "arrival_offset_s",
            "nested_rank",
            "source_item_id",
        ]
    )

    for task in ordered_tasks.itertuples(
        index=False
    ):
        task_id = str(task.source_item_id)
        arrival_s = float(task.arrival_offset_s)
        demand_cpu = float(task.requested_cpu)
        demand_memory = float(task.requested_memory)
        initial_region = int(task.initial_region_id)

        candidates = []

        for node in nodes_ordered.itertuples(
            index=False
        ):
            if (
                demand_cpu
                > float(node.cpu_capacity) + 1e-9
            ):
                continue

            if (
                demand_memory
                > float(node.memory_capacity) + 1e-9
            ):
                continue

            runtime_s = task_runtime_s(
                observed_cpu_work=float(
                    task.observed_cpu_work
                ),
                requested_cpu=demand_cpu,
                node_type=str(node.node_type),
                speed_factors=speed_factors,
            )

            dispatch_s = network.dispatch_delay_s(
                source_region=initial_region,
                destination_region=int(
                    node.region_id
                ),
                key=f"{task_id}|{node.node_id}",
                seed=seed,
            )

            release_s = arrival_s + dispatch_s

            start_s = earliest_feasible_start(
                reservations=reservations[
                    str(node.node_id)
                ],
                release_s=release_s,
                duration_s=runtime_s,
                demand_cpu=demand_cpu,
                demand_memory=demand_memory,
                cpu_capacity=float(
                    node.cpu_capacity
                ),
                memory_capacity=float(
                    node.memory_capacity
                ),
            )

            finish_s = start_s + runtime_s
            start_carbon = carbon.intensity(
                int(node.region_id),
                start_s,
            )

            candidates.append({
                "node": node,
                "runtime_s": runtime_s,
                "dispatch_s": dispatch_s,
                "release_s": release_s,
                "start_s": start_s,
                "finish_s": finish_s,
                "start_carbon": start_carbon,
                "same_region": (
                    int(node.region_id)
                    == initial_region
                ),
            })

        if not candidates:
            raise RuntimeError(
                f"No feasible node for task {task_id}."
            )

        candidates.sort(
            key=lambda item: (
                item["finish_s"],
                item["start_carbon"],
                not item["same_region"],
                str(item["node"].node_id),
            )
        )

        selected = candidates[0]
        node = selected["node"]

        reservation = Reservation(
            task_id=task_id,
            start_s=float(selected["start_s"]),
            finish_s=float(
                selected["finish_s"]
            ),
            cpu=demand_cpu,
            memory=demand_memory,
        )

        reservations[
            str(node.node_id)
        ].append(reservation)

        reservations[
            str(node.node_id)
        ].sort(
            key=lambda item: (
                item.start_s,
                item.finish_s,
                item.task_id,
            )
        )

        finish_s = float(selected["finish_s"])
        deadline_s = float(
            task.deadline_offset_s
        )

        scheduled_rows.append({
            "dataset": str(task.dataset),
            "source_item_id": task_id,
            "nested_rank": int(task.nested_rank),
            "arrival_offset_s": arrival_s,
            "initial_region_id": initial_region,
            "node_id": str(node.node_id),
            "node_region_id": int(
                node.region_id
            ),
            "node_type": str(node.node_type),
            "requested_cpu": demand_cpu,
            "requested_memory": demand_memory,
            "node_cpu_capacity": float(
                node.cpu_capacity
            ),
            "node_memory_capacity": float(
                node.memory_capacity
            ),
            "dispatch_delay_s": float(
                selected["dispatch_s"]
            ),
            "release_after_dispatch_s": float(
                selected["release_s"]
            ),
            "queue_delay_s": float(
                selected["start_s"]
                - selected["release_s"]
            ),
            "execution_runtime_s": float(
                selected["runtime_s"]
            ),
            "start_s": float(
                selected["start_s"]
            ),
            "finish_s": finish_s,
            "response_time_s": (
                finish_s - arrival_s
            ),
            "deadline_offset_s": deadline_s,
            "deadline_missed": (
                finish_s > deadline_s + 1e-9
            ),
            "start_carbon_gco2_per_kwh": float(
                selected["start_carbon"]
            ),
            "migration_count": 0,
            "migration_time_s": 0.0,
            "migration_energy_wh": 0.0,
            "migration_emissions_g": 0.0,
        })

    schedule = pd.DataFrame(scheduled_rows)

    return schedule, reservations


def audit_capacity(
    nodes: pd.DataFrame,
    reservations: dict[
        str,
        list[Reservation],
    ],
) -> pd.DataFrame:
    rows = []

    node_map = nodes.set_index("node_id")

    for node_id, node_reservations in reservations.items():
        node = node_map.loc[node_id]
        event_points = sorted({
            point
            for reservation in node_reservations
            for point in (
                reservation.start_s,
                reservation.finish_s,
            )
        })

        max_cpu = 0.0
        max_memory = 0.0
        cpu_violations = 0
        memory_violations = 0

        for left, right in zip(
            event_points[:-1],
            event_points[1:],
        ):
            if right <= left + EPSILON:
                continue

            midpoint = 0.5 * (left + right)

            active_cpu = sum(
                reservation.cpu
                for reservation in node_reservations
                if (
                    reservation.start_s
                    <= midpoint
                    < reservation.finish_s
                )
            )

            active_memory = sum(
                reservation.memory
                for reservation in node_reservations
                if (
                    reservation.start_s
                    <= midpoint
                    < reservation.finish_s
                )
            )

            max_cpu = max(
                max_cpu,
                active_cpu,
            )

            max_memory = max(
                max_memory,
                active_memory,
            )

            if (
                active_cpu
                > float(node.cpu_capacity) + 1e-9
            ):
                cpu_violations += 1

            if (
                active_memory
                > float(node.memory_capacity) + 1e-9
            ):
                memory_violations += 1

        rows.append({
            "node_id": node_id,
            "reservation_count": len(
                node_reservations
            ),
            "max_active_cpu": max_cpu,
            "cpu_capacity": float(
                node.cpu_capacity
            ),
            "max_active_memory": max_memory,
            "memory_capacity": float(
                node.memory_capacity
            ),
            "cpu_violation_segments": (
                cpu_violations
            ),
            "memory_violation_segments": (
                memory_violations
            ),
        })

    return pd.DataFrame(rows)


def integrate_schedule_energy(
    nodes: pd.DataFrame,
    reservations: dict[
        str,
        list[Reservation],
    ],
    carbon: CarbonSeries,
    origin_s: float,
    makespan_finish_s: float,
) -> dict[str, float]:
    if makespan_finish_s <= origin_s:
        raise ValueError(
            "Schedule finish must exceed origin."
        )

    node_map = nodes.set_index("node_id")

    total_energy_wh = 0.0
    total_emissions_g = 0.0
    total_it_energy_wh = 0.0

    for node_id, node in node_map.iterrows():
        node_reservations = reservations[
            str(node_id)
        ]

        event_points = {
            float(origin_s),
            float(makespan_finish_s),
            *carbon.slot_boundaries(
                origin_s,
                makespan_finish_s,
            ),
        }

        for reservation in node_reservations:
            if (
                origin_s
                < reservation.start_s
                < makespan_finish_s
            ):
                event_points.add(
                    reservation.start_s
                )

            if (
                origin_s
                < reservation.finish_s
                < makespan_finish_s
            ):
                event_points.add(
                    reservation.finish_s
                )

        ordered = sorted(event_points)

        for left, right in zip(
            ordered[:-1],
            ordered[1:],
        ):
            if right <= left + EPSILON:
                continue

            midpoint = 0.5 * (left + right)

            active_cpu = sum(
                reservation.cpu
                for reservation in node_reservations
                if (
                    reservation.start_s
                    <= midpoint
                    < reservation.finish_s
                )
            )

            utilization = min(
                1.0,
                max(
                    0.0,
                    active_cpu
                    / float(node.cpu_capacity),
                ),
            )

            it_power_w = (
                float(node.idle_power_w)
                + (
                    float(node.peak_power_w)
                    - float(node.idle_power_w)
                )
                * utilization
            )

            facility_power_w = (
                it_power_w
                * float(node.regional_pue)
            )

            duration_h = (
                right - left
            ) / 3600.0

            it_energy_wh = (
                it_power_w
                * duration_h
            )

            facility_energy_wh = (
                facility_power_w
                * duration_h
            )

            intensity = carbon.intensity(
                int(node.region_id),
                midpoint,
            )

            emissions_g = (
                facility_energy_wh
                / 1000.0
                * intensity
            )

            total_it_energy_wh += it_energy_wh
            total_energy_wh += facility_energy_wh
            total_emissions_g += emissions_g

    return {
        "total_it_energy_wh": float(
            total_it_energy_wh
        ),
        "total_facility_energy_wh": float(
            total_energy_wh
        ),
        "total_emissions_g": float(
            total_emissions_g
        ),
    }


def integrate_time_weighted_carbon(
    schedule: pd.DataFrame,
    carbon: CarbonSeries,
) -> float:
    total = 0.0

    for row in schedule.itertuples(index=False):
        boundaries = [
            float(row.start_s),
            *carbon.slot_boundaries(
                float(row.start_s),
                float(row.finish_s),
            ),
            float(row.finish_s),
        ]

        for left, right in zip(
            boundaries[:-1],
            boundaries[1:],
        ):
            if right <= left + EPSILON:
                continue

            midpoint = 0.5 * (left + right)
            intensity = carbon.intensity(
                int(row.node_region_id),
                midpoint,
            )
            total += (
                right - left
            ) * intensity

    return float(total)


def summarize_schedule(
    schedule: pd.DataFrame,
    nodes: pd.DataFrame,
    reservations: dict[
        str,
        list[Reservation],
    ],
    carbon: CarbonSeries,
) -> dict[str, float]:
    if schedule.empty:
        raise ValueError("Schedule is empty.")

    origin_s = float(
        schedule["arrival_offset_s"].min()
    )

    finish_s = float(
        schedule["finish_s"].max()
    )

    energy = integrate_schedule_energy(
        nodes=nodes,
        reservations=reservations,
        carbon=carbon,
        origin_s=origin_s,
        makespan_finish_s=finish_s,
    )

    time_weighted_carbon = (
        integrate_time_weighted_carbon(
            schedule=schedule,
            carbon=carbon,
        )
    )

    return {
        "task_count": int(len(schedule)),
        "makespan_s": float(
            finish_s - origin_s
        ),
        "mean_response_time_s": float(
            schedule["response_time_s"].mean()
        ),
        "p95_response_time_s": float(
            schedule["response_time_s"].quantile(
                0.95
            )
        ),
        "mean_queue_delay_s": float(
            schedule["queue_delay_s"].mean()
        ),
        "deadline_miss_count": int(
            schedule["deadline_missed"].sum()
        ),
        "deadline_miss_ratio": float(
            schedule["deadline_missed"].mean()
        ),
        "migration_count": int(
            schedule["migration_count"].sum()
        ),
        "migration_time_s": float(
            schedule["migration_time_s"].sum()
        ),
        "migration_energy_wh": float(
            schedule["migration_energy_wh"].sum()
        ),
        "migration_emissions_g": float(
            schedule["migration_emissions_g"].sum()
        ),
        "time_weighted_carbon_gco2_per_kwh_s": (
            time_weighted_carbon
        ),
        **energy,
    }


def stable_schedule_hash(
    schedule: pd.DataFrame,
) -> str:
    columns = [
        "source_item_id",
        "node_id",
        "start_s",
        "finish_s",
        "deadline_missed",
    ]

    normalized = schedule[
        columns
    ].sort_values(
        "source_item_id"
    ).copy()

    for column in [
        "start_s",
        "finish_s",
    ]:
        normalized[column] = normalized[
            column
        ].map(
            lambda value: format(
                float(value),
                ".12f",
            )
        )

    payload = normalized.to_csv(
        index=False
    ).encode("utf-8")

    return hashlib.sha256(payload).hexdigest()
