
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
from typing import Any

import numpy as np
import pandas as pd

import hcsmo_simulator_core as sim
import hcsmo_method_aligned_v1_1 as method
import hcsmo_rolling_horizon_engine_v1_1 as rolling


EPSILON = 1e-12

OBJECTIVE_NAMES = (
    "carbon_emissions_g",
    "makespan_s",
    "total_energy_wh",
    "migration_volume_gib",
)


@dataclass
class IntervalEvaluation:
    assignment: tuple[int, ...]
    raw_objectives: np.ndarray
    score: float
    planned: pd.DataFrame
    reservations: dict[str, list[sim.Reservation]]
    migration_count: int
    migration_volume_gib: float
    migration_time_s: float
    migration_energy_wh: float
    migration_emissions_g: float


class RollingIntervalEvaluator:
    def __init__(
        self,
        engine: rolling.RollingHorizonEngine,
        interval_start_s: float,
        eligible_indices: list[int],
        baseline_assignment: tuple[int, ...],
        objective_weights: np.ndarray,
        maximum_reassignments: int,
        migration_volume_limit_gib: float,
        history_bounds: dict[str, dict[str, float]] | None,
        seed: int,
    ) -> None:
        self.engine = engine
        self.interval_start_s = float(interval_start_s)
        self.eligible_indices = tuple(int(value) for value in eligible_indices)
        self.baseline_assignment = tuple(int(value) for value in baseline_assignment)
        self.weights = np.asarray(objective_weights, dtype=float)
        self.maximum_reassignments = int(maximum_reassignments)
        self.migration_volume_limit_gib = float(migration_volume_limit_gib)
        self.history_bounds = history_bounds
        self.seed = int(seed)

        if len(self.eligible_indices) == 0:
            raise ValueError("At least one eligible task is required.")

        if len(self.baseline_assignment) != len(self.eligible_indices):
            raise ValueError("Baseline assignment length mismatch.")

        if not math.isclose(
            float(self.weights.sum()),
            1.0,
            rel_tol=0.0,
            abs_tol=1e-12,
        ):
            raise ValueError("Objective weights must sum to one.")

        self.feasible_nodes = [
            self.engine.feasible_nodes[task_index]
            for task_index in self.eligible_indices
        ]

        self.raw_cache: dict[tuple[int, ...], tuple] = {}
        self.lower_bounds: np.ndarray | None = None
        self.upper_bounds: np.ndarray | None = None
        self.normalization_sources: list[str] = []

    @property
    def dimension(self) -> int:
        return len(self.eligible_indices)

    @property
    def node_count(self) -> int:
        return len(self.engine.nodes)

    def position_from_assignment(
        self,
        assignment: tuple[int, ...],
    ) -> np.ndarray:
        return np.asarray(assignment, dtype=float)

    def decode_position(
        self,
        position: np.ndarray,
    ) -> tuple[int, ...]:
        clipped = np.clip(
            np.asarray(position, dtype=float),
            0.0,
            float(self.node_count - 1),
        )
        decoded = np.rint(clipped).astype(int)
        return self.repair_assignment(decoded)

    def _is_pending(
        self,
        task_index: int,
    ) -> bool:
        return pd.notna(
            self.engine.state.at[
                task_index,
                "current_node_index",
            ]
        )

    def _previous_node(
        self,
        task_index: int,
    ) -> int | None:
        value = self.engine.state.at[
            task_index,
            "current_node_index",
        ]
        if pd.isna(value):
            return None
        return int(value)

    def _migration_details(
        self,
        assignment: tuple[int, ...],
    ) -> tuple[np.ndarray, np.ndarray]:
        mask = np.zeros(
            self.dimension,
            dtype=bool,
        )
        volumes = np.zeros(
            self.dimension,
            dtype=float,
        )

        for local_index, task_index in enumerate(
            self.eligible_indices
        ):
            previous_node = self._previous_node(task_index)

            if previous_node is None:
                continue

            previous_region = int(
                self.engine.nodes.iloc[
                    previous_node
                ]["region_id"]
            )
            new_region = int(
                self.engine.nodes.iloc[
                    int(assignment[local_index])
                ]["region_id"]
            )

            if previous_region != new_region:
                mask[local_index] = True
                volumes[local_index] = (
                    float(
                        self.engine.state.at[
                            task_index,
                            "migration_state_mib",
                        ]
                    )
                    / 1024.0
                )

        return mask, volumes

    def repair_assignment(
        self,
        decoded: np.ndarray,
    ) -> tuple[int, ...]:
        repaired = []

        for local_index, raw_node in enumerate(decoded):
            feasible = self.feasible_nodes[local_index]
            requested = int(
                np.clip(
                    int(raw_node),
                    0,
                    self.node_count - 1,
                )
            )

            if requested in feasible:
                repaired.append(requested)
            else:
                chosen = min(
                    feasible.tolist(),
                    key=lambda candidate: (
                        abs(candidate - requested),
                        candidate,
                    ),
                )
                repaired.append(int(chosen))

        repaired_tuple = tuple(repaired)
        migration_mask, migration_volumes = self._migration_details(
            repaired_tuple
        )

        migration_indices = np.where(
            migration_mask
        )[0].tolist()

        migration_indices.sort(
            key=lambda local_index: (
                float(migration_volumes[local_index]),
                int(
                    self.engine.state.at[
                        self.eligible_indices[local_index],
                        "nested_rank",
                    ]
                ),
                str(
                    self.engine.state.at[
                        self.eligible_indices[local_index],
                        "source_item_id",
                    ]
                ),
            )
        )

        kept: list[int] = []
        cumulative_volume = 0.0
        repaired_list = list(repaired_tuple)

        for local_index in migration_indices:
            task_volume = float(
                migration_volumes[local_index]
            )
            count_ok = (
                len(kept)
                < self.maximum_reassignments
            )
            volume_ok = (
                cumulative_volume
                + task_volume
                <= self.migration_volume_limit_gib
                + EPSILON
            )

            if count_ok and volume_ok:
                kept.append(local_index)
                cumulative_volume += task_volume
            else:
                repaired_list[local_index] = (
                    self.baseline_assignment[local_index]
                )

        return tuple(
            int(value)
            for value in repaired_list
        )

    def random_assignment(
        self,
        rng: np.random.Generator,
    ) -> tuple[int, ...]:
        assignment = list(
            self.baseline_assignment
        )

        for local_index, feasible in enumerate(
            self.feasible_nodes
        ):
            if rng.random() < 0.35:
                assignment[local_index] = int(
                    rng.choice(feasible)
                )

        return self.repair_assignment(
            np.asarray(assignment, dtype=int)
        )

    def _copy_reservations(
        self,
    ) -> dict[str, list[sim.Reservation]]:
        source = self.engine._running_reservations(
            self.interval_start_s
        )

        return {
            key: list(value)
            for key, value in source.items()
        }

    def _evaluate_raw(
        self,
        assignment: tuple[int, ...],
    ):
        repaired = self.repair_assignment(
            np.asarray(assignment, dtype=int)
        )

        if repaired in self.raw_cache:
            cached = self.raw_cache[repaired]
            return (
                cached[0].copy(),
                cached[1].copy(),
                {
                    key: list(value)
                    for key, value in cached[2].items()
                },
                dict(cached[3]),
            )

        reservations = self._copy_reservations()
        planned_rows = []
        migration_count = 0
        migration_volume_gib = 0.0
        migration_time_s = 0.0
        migration_energy_wh = 0.0
        migration_emissions_g = 0.0

        for local_index, task_index in enumerate(
            self.eligible_indices
        ):
            task = self.engine.state.iloc[
                task_index
            ]
            previous_node = self._previous_node(
                task_index
            )
            is_new = previous_node is None
            node_index = int(
                repaired[local_index]
            )

            placement = self.engine._candidate_plan(
                task_index=task_index,
                node_index=node_index,
                interval_start_s=self.interval_start_s,
                reservations=reservations,
                is_new=is_new,
                previous_node_index=previous_node,
            )

            node = self.engine.nodes.iloc[
                node_index
            ]
            node_id = str(
                node["node_id"]
            )

            reservation = sim.Reservation(
                task_id=str(
                    task["source_item_id"]
                ),
                start_s=float(
                    placement.start_s
                ),
                finish_s=float(
                    placement.finish_s
                ),
                cpu=float(
                    task["requested_cpu"]
                ),
                memory=float(
                    task["requested_memory"]
                ),
            )

            reservations[node_id].append(
                reservation
            )
            reservations[node_id].sort(
                key=lambda item: (
                    item.start_s,
                    item.finish_s,
                    item.task_id,
                )
            )

            migration_count += int(
                placement.migration_count
            )
            migration_volume_gib += float(
                placement.migration_volume_gib
            )
            migration_time_s += float(
                placement.migration_time_s
            )
            migration_energy_wh += float(
                placement.migration_energy_wh
            )
            migration_emissions_g += float(
                placement.migration_emissions_g
            )

            planned_rows.append({
                "task_index": int(task_index),
                "source_item_id": str(
                    task["source_item_id"]
                ),
                "nested_rank": int(
                    task["nested_rank"]
                ),
                "node_index": int(
                    node_index
                ),
                "node_id": node_id,
                "node_region_id": int(
                    node["region_id"]
                ),
                "start_s": float(
                    placement.start_s
                ),
                "finish_s": float(
                    placement.finish_s
                ),
                "runtime_s": float(
                    placement.runtime_s
                ),
                "data_ready_s": float(
                    placement.data_ready_s
                ),
                "dispatch_delay_s": float(
                    placement.dispatch_delay_s
                ),
                "migration_count": int(
                    placement.migration_count
                ),
                "migration_volume_gib": float(
                    placement.migration_volume_gib
                ),
                "migration_time_s": float(
                    placement.migration_time_s
                ),
                "migration_energy_wh": float(
                    placement.migration_energy_wh
                ),
                "migration_emissions_g": float(
                    placement.migration_emissions_g
                ),
            })

        planned = pd.DataFrame(
            planned_rows
        )

        running_reservations = [
            reservation
            for values in self.engine._running_reservations(
                self.interval_start_s
            ).values()
            for reservation in values
        ]

        finish_candidates = planned[
            "finish_s"
        ].tolist()

        finish_candidates.extend(
            reservation.finish_s
            for reservation in running_reservations
        )

        finish_s = max(
            finish_candidates
        )

        energy = sim.integrate_schedule_energy(
            nodes=self.engine.nodes,
            reservations=reservations,
            carbon=self.engine.carbon,
            origin_s=self.interval_start_s,
            makespan_finish_s=float(
                finish_s
            ),
        )

        total_energy_wh = (
            float(
                energy[
                    "total_facility_energy_wh"
                ]
            )
            + migration_energy_wh
        )

        carbon_emissions_g = (
            float(
                energy[
                    "total_emissions_g"
                ]
            )
            + migration_emissions_g
        )

        raw = np.array(
            [
                carbon_emissions_g,
                float(
                    finish_s
                    - self.interval_start_s
                ),
                total_energy_wh,
                migration_volume_gib,
            ],
            dtype=float,
        )

        details = {
            "migration_count": int(
                migration_count
            ),
            "migration_volume_gib": float(
                migration_volume_gib
            ),
            "migration_time_s": float(
                migration_time_s
            ),
            "migration_energy_wh": float(
                migration_energy_wh
            ),
            "migration_emissions_g": float(
                migration_emissions_g
            ),
        }

        self.raw_cache[repaired] = (
            raw.copy(),
            planned.copy(),
            {
                key: list(value)
                for key, value in reservations.items()
            },
            dict(details),
        )

        return (
            raw,
            planned,
            reservations,
            details,
        )

    def calibrate(
        self,
        assignments: list[tuple[int, ...]],
    ) -> None:
        matrix = []

        for assignment in assignments:
            raw, _, _, _ = self._evaluate_raw(
                assignment
            )
            matrix.append(raw)

        matrix = np.vstack(matrix)

        bootstrap_lower = matrix.min(
            axis=0
        )
        bootstrap_upper = matrix.max(
            axis=0
        )

        lower = bootstrap_lower.copy()
        upper = bootstrap_upper.copy()
        sources = []

        for index, objective_name in enumerate(
            OBJECTIVE_NAMES
        ):
            history_used = False

            if (
                self.history_bounds is not None
                and objective_name
                in self.history_bounds
            ):
                minimum = float(
                    self.history_bounds[
                        objective_name
                    ]["minimum"]
                )
                maximum = float(
                    self.history_bounds[
                        objective_name
                    ]["maximum"]
                )

                if (
                    math.isfinite(minimum)
                    and math.isfinite(maximum)
                    and maximum
                    - minimum
                    > EPSILON
                ):
                    lower[index] = minimum
                    upper[index] = maximum
                    history_used = True

            if history_used:
                sources.append(
                    "past_window"
                )
            else:
                sources.append(
                    "deterministic_interval_bootstrap"
                )

        equal = (
            upper - lower
            <= EPSILON
        )
        upper[equal] = (
            lower[equal]
            + 1.0
        )

        self.lower_bounds = lower
        self.upper_bounds = upper
        self.normalization_sources = sources

    def score_raw(
        self,
        raw: np.ndarray,
    ) -> float:
        if (
            self.lower_bounds is None
            or self.upper_bounds is None
        ):
            raise RuntimeError(
                "Evaluator must be calibrated."
            )

        normalized = (
            raw - self.lower_bounds
        ) / (
            self.upper_bounds
            - self.lower_bounds
        )

        normalized = np.clip(
            normalized,
            0.0,
            1.0,
        )

        return float(
            np.dot(
                self.weights,
                normalized,
            )
        )

    def evaluate_assignment(
        self,
        assignment: tuple[int, ...],
    ) -> IntervalEvaluation:
        repaired = self.repair_assignment(
            np.asarray(assignment, dtype=int)
        )

        raw, planned, reservations, details = (
            self._evaluate_raw(repaired)
        )

        return IntervalEvaluation(
            assignment=repaired,
            raw_objectives=raw,
            score=self.score_raw(raw),
            planned=planned,
            reservations=reservations,
            migration_count=int(
                details[
                    "migration_count"
                ]
            ),
            migration_volume_gib=float(
                details[
                    "migration_volume_gib"
                ]
            ),
            migration_time_s=float(
                details[
                    "migration_time_s"
                ]
            ),
            migration_energy_wh=float(
                details[
                    "migration_energy_wh"
                ]
            ),
            migration_emissions_g=float(
                details[
                    "migration_emissions_g"
                ]
            ),
        )

    def evaluate_position(
        self,
        position: np.ndarray,
    ) -> IntervalEvaluation:
        return self.evaluate_assignment(
            self.decode_position(position)
        )


class IntervalBoundedSMO:
    def __init__(
        self,
        evaluator: RollingIntervalEvaluator,
        fuzzy_decision: method.FuzzyDecision,
        population_size: int,
        iterations: int,
        perturbation_rate: float,
        seed: int,
    ) -> None:
        self.evaluator = evaluator
        self.fuzzy_decision = fuzzy_decision
        self.population_size = int(
            population_size
        )
        self.iterations = int(
            iterations
        )
        self.perturbation_rate = float(
            perturbation_rate
        )
        self.seed = int(seed)

        if self.population_size < 2:
            raise ValueError(
                "Population size must be at least two."
            )

    def run(self) -> dict[str, Any]:
        rng = np.random.default_rng(
            self.seed
        )

        assignments = [
            self.evaluator.baseline_assignment
        ]

        while len(assignments) < self.population_size:
            assignments.append(
                self.evaluator.random_assignment(
                    rng
                )
            )

        self.evaluator.calibrate(
            assignments
        )

        population = np.vstack(
            [
                self.evaluator.position_from_assignment(
                    assignment
                )
                for assignment in assignments
            ]
        )

        evaluations = [
            self.evaluator.evaluate_assignment(
                assignment
            )
            for assignment in assignments
        ]

        scores = np.array(
            [
                evaluation.score
                for evaluation in evaluations
            ],
            dtype=float,
        )

        baseline_evaluation = (
            self.evaluator.evaluate_assignment(
                self.evaluator.baseline_assignment
            )
        )

        best_index = int(
            np.argmin(scores)
        )

        elite_position = population[
            best_index
        ].copy()

        elite_evaluation = evaluations[
            best_index
        ]

        alpha = float(
            self.fuzzy_decision.alpha
        )
        beta = float(
            self.fuzzy_decision.beta
        )

        convergence_rows = []

        for iteration in range(
            1,
            self.iterations + 1,
        ):
            start_score = float(
                elite_evaluation.score
            )

            for individual_index in range(
                self.population_size
            ):
                current = population[
                    individual_index
                ]

                mask = (
                    rng.random(
                        self.evaluator.dimension
                    )
                    < self.perturbation_rate
                )

                if not mask.any():
                    mask[
                        int(
                            rng.integers(
                                0,
                                self.evaluator.dimension,
                            )
                        )
                    ] = True

                epsilon = rng.uniform(
                    -1.0,
                    1.0,
                    size=self.evaluator.dimension,
                )

                candidate = current.copy()
                candidate[mask] = (
                    current[mask]
                    + alpha
                    * (
                        elite_position[mask]
                        - current[mask]
                    )
                    + beta
                    * epsilon[mask]
                )

                candidate = np.clip(
                    candidate,
                    0.0,
                    float(
                        self.evaluator.node_count
                        - 1
                    ),
                )

                candidate_evaluation = (
                    self.evaluator.evaluate_position(
                        candidate
                    )
                )

                if (
                    candidate_evaluation.score
                    < scores[individual_index]
                    - EPSILON
                ):
                    population[
                        individual_index
                    ] = candidate
                    evaluations[
                        individual_index
                    ] = candidate_evaluation
                    scores[
                        individual_index
                    ] = candidate_evaluation.score

            current_best_index = int(
                np.argmin(scores)
            )
            current_best = evaluations[
                current_best_index
            ]

            if (
                current_best.score
                < elite_evaluation.score
                - EPSILON
            ):
                elite_position = population[
                    current_best_index
                ].copy()
                elite_evaluation = current_best

            convergence_rows.append({
                "iteration": int(iteration),
                "best_score": float(
                    elite_evaluation.score
                ),
                "iteration_start_best_score": float(
                    start_score
                ),
                "carbon_emissions_g": float(
                    elite_evaluation.raw_objectives[
                        0
                    ]
                ),
                "makespan_s": float(
                    elite_evaluation.raw_objectives[
                        1
                    ]
                ),
                "total_energy_wh": float(
                    elite_evaluation.raw_objectives[
                        2
                    ]
                ),
                "migration_volume_gib": float(
                    elite_evaluation.raw_objectives[
                        3
                    ]
                ),
                "migration_count": int(
                    elite_evaluation.migration_count
                ),
                "alpha": alpha,
                "beta": beta,
            })

            if (
                elite_evaluation.score
                > start_score
                + EPSILON
            ):
                raise RuntimeError(
                    "Elitist interval score increased."
                )

        if (
            elite_evaluation.assignment
            != baseline_evaluation.assignment
            and elite_evaluation.score
            < baseline_evaluation.score
            - EPSILON
        ):
            accepted = elite_evaluation
            candidate_accepted = True
        else:
            accepted = baseline_evaluation
            candidate_accepted = False

        return {
            "baseline_evaluation": baseline_evaluation,
            "candidate_evaluation": elite_evaluation,
            "accepted_evaluation": accepted,
            "candidate_accepted": candidate_accepted,
            "convergence": pd.DataFrame(
                convergence_rows
            ),
            "normalization_lower_bounds": (
                self.evaluator.lower_bounds.copy()
            ),
            "normalization_upper_bounds": (
                self.evaluator.upper_bounds.copy()
            ),
            "normalization_sources": tuple(
                self.evaluator.normalization_sources
            ),
            "cache_size": len(
                self.evaluator.raw_cache
            ),
        }


class HCSMORollingPlanner:
    def __init__(
        self,
        engine: rolling.RollingHorizonEngine,
        controller: method.AlignedMamdaniController,
        context_computer: method.ContextSignalComputer,
        normalization_history: rolling.RollingNormalizationHistory,
        population_size: int,
        iterations: int,
        perturbation_rate: float,
        maximum_reassignments: int,
        migration_volume_limit_gib: float,
        seed: int,
    ) -> None:
        self.engine = engine
        self.controller = controller
        self.context_computer = context_computer
        self.normalization_history = normalization_history
        self.population_size = int(
            population_size
        )
        self.iterations = int(
            iterations
        )
        self.perturbation_rate = float(
            perturbation_rate
        )
        self.maximum_reassignments = int(
            maximum_reassignments
        )
        self.migration_volume_limit_gib = float(
            migration_volume_limit_gib
        )
        self.seed = int(seed)

    def eligible_indices(
        self,
        interval_start_s: float,
    ) -> list[int]:
        interval_end_s = (
            float(interval_start_s)
            + self.engine.interval_seconds
        )

        status = self.engine.status_frame(
            interval_start_s
        )

        result = []

        for task_index, row in self.engine.state.iterrows():
            status_value = status.iloc[
                task_index
            ]["status"]

            if (
                status_value
                not in {
                    "completed",
                    "running",
                }
                and float(
                    row[
                        "arrival_offset_s"
                    ]
                )
                < interval_end_s
                - EPSILON
            ):
                result.append(
                    int(task_index)
                )

        result.sort(
            key=lambda index: (
                float(
                    self.engine.state.at[
                        index,
                        "arrival_offset_s",
                    ]
                ),
                int(
                    self.engine.state.at[
                        index,
                        "nested_rank",
                    ]
                ),
                str(
                    self.engine.state.at[
                        index,
                        "source_item_id",
                    ]
                ),
            )
        )

        return result

    def build_baseline_assignment(
        self,
        interval_start_s: float,
        eligible_indices: list[int],
    ) -> tuple[int, ...]:
        reservations = self.engine._running_reservations(
            interval_start_s
        )

        assignments = []

        for task_index in eligible_indices:
            row = self.engine.state.iloc[
                task_index
            ]

            if pd.notna(
                row[
                    "current_node_index"
                ]
            ):
                node_index = int(
                    row[
                        "current_node_index"
                    ]
                )
                placement = self.engine._candidate_plan(
                    task_index=task_index,
                    node_index=node_index,
                    interval_start_s=interval_start_s,
                    reservations=reservations,
                    is_new=False,
                    previous_node_index=node_index,
                )
            else:
                placement = self.engine._earliest_finish_plan(
                    task_index=task_index,
                    interval_start_s=interval_start_s,
                    reservations=reservations,
                    is_new=True,
                    previous_node_index=None,
                )
                node_index = int(
                    placement.node_index
                )

            node_id = str(
                self.engine.nodes.iloc[
                    node_index
                ]["node_id"]
            )

            reservations[node_id].append(
                sim.Reservation(
                    task_id=str(
                        row[
                            "source_item_id"
                        ]
                    ),
                    start_s=float(
                        placement.start_s
                    ),
                    finish_s=float(
                        placement.finish_s
                    ),
                    cpu=float(
                        row[
                            "requested_cpu"
                        ]
                    ),
                    memory=float(
                        row[
                            "requested_memory"
                        ]
                    ),
                )
            )
            reservations[node_id].sort(
                key=lambda item: (
                    item.start_s,
                    item.finish_s,
                    item.task_id,
                )
            )

            assignments.append(
                node_index
            )

        return tuple(assignments)

    def plan_cycle(
        self,
        cycle_index: int,
        interval_start_s: float,
        previous_cycle_migration_volume_gib: float,
    ) -> dict[str, Any] | None:
        eligible = self.eligible_indices(
            interval_start_s
        )

        if not eligible:
            return None

        baseline_assignment = (
            self.build_baseline_assignment(
                interval_start_s,
                eligible,
            )
        )

        context_tasks = self.engine.state.iloc[
            eligible
        ].copy()

        context = self.context_computer.compute(
            tasks=context_tasks,
            interval_start_s=interval_start_s,
            previous_cycle_migration_volume_gib=(
                previous_cycle_migration_volume_gib
            ),
            migration_volume_limit_gib=(
                self.migration_volume_limit_gib
            ),
        )

        decision = self.controller.infer(
            context.eta,
            context.delta,
            context.nu,
        )

        evaluator = RollingIntervalEvaluator(
            engine=self.engine,
            interval_start_s=interval_start_s,
            eligible_indices=eligible,
            baseline_assignment=baseline_assignment,
            objective_weights=decision.weights(),
            maximum_reassignments=(
                self.maximum_reassignments
            ),
            migration_volume_limit_gib=(
                self.migration_volume_limit_gib
            ),
            history_bounds=(
                self.normalization_history.bounds_before_current()
            ),
            seed=(
                self.seed
                + 1009
                * int(cycle_index)
            ),
        )

        optimizer = IntervalBoundedSMO(
            evaluator=evaluator,
            fuzzy_decision=decision,
            population_size=self.population_size,
            iterations=self.iterations,
            perturbation_rate=self.perturbation_rate,
            seed=(
                self.seed
                + 1009
                * int(cycle_index)
            ),
        )

        optimization = optimizer.run()
        accepted = optimization[
            "accepted_evaluation"
        ]

        target_map = {
            int(task_index): int(
                accepted.assignment[
                    local_index
                ]
            )
            for local_index, task_index in enumerate(
                eligible
            )
        }

        return {
            "cycle_index": int(cycle_index),
            "interval_start_s": float(
                interval_start_s
            ),
            "eligible_indices": tuple(
                eligible
            ),
            "baseline_assignment": (
                baseline_assignment
            ),
            "target_map": target_map,
            "context": context,
            "decision": decision,
            **optimization,
        }

    @staticmethod
    def policy_from_plan(
        plan: dict[str, Any],
    ):
        target_map = dict(
            plan["target_map"]
        )

        def policy(
            task_index: int,
            task: pd.Series,
            previous_node: int | None,
            status_label: str,
            cycle_index: int,
        ) -> int | None:
            return target_map.get(
                int(task_index),
                previous_node,
            )

        return policy


def assignment_sha256(
    assignment: tuple[int, ...],
) -> str:
    payload = ",".join(
        str(value)
        for value in assignment
    ).encode("utf-8")

    return hashlib.sha256(
        payload
    ).hexdigest()
