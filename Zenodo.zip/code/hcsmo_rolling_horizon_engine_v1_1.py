
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
from typing import Callable

import numpy as np
import pandas as pd

import hcsmo_simulator_core as sim


EPSILON = 1e-12


@dataclass(frozen=True)
class PlannedPlacement:
    task_index: int
    node_index: int
    start_s: float
    finish_s: float
    runtime_s: float
    data_ready_s: float
    dispatch_delay_s: float
    migration_count: int
    migration_volume_gib: float
    migration_time_s: float
    migration_energy_wh: float
    migration_emissions_g: float


class RollingNormalizationHistory:
    def __init__(
        self,
        maximum_intervals: int,
        objective_names: tuple[str, ...],
    ) -> None:
        self.maximum_intervals = int(
            maximum_intervals
        )

        self.objective_names = tuple(
            objective_names
        )

        if self.maximum_intervals <= 0:
            raise ValueError(
                "maximum_intervals must be positive."
            )

        self.records: list[
            dict[str, float]
        ] = []

    def bounds_before_current(
        self,
    ) -> dict[str, dict[str, float]] | None:
        if not self.records:
            return None

        frame = pd.DataFrame(
            self.records[
                -self.maximum_intervals:
            ]
        )

        return {
            name: {
                "minimum": float(
                    frame[name].min()
                ),
                "maximum": float(
                    frame[name].max()
                ),
            }
            for name in self.objective_names
        }

    def append(
        self,
        values: dict[str, float],
    ) -> None:
        missing = (
            set(
                self.objective_names
            )
            - set(values)
        )

        if missing:
            raise ValueError(
                f"Missing objectives: {sorted(missing)}"
            )

        record = {
            name: float(
                values[name]
            )
            for name in self.objective_names
        }

        if not np.isfinite(
            np.array(
                list(
                    record.values()
                ),
                dtype=float,
            )
        ).all():
            raise ValueError(
                "Normalization history requires finite values."
            )

        self.records.append(
            record
        )


class RollingHorizonEngine:
    def __init__(
        self,
        tasks: pd.DataFrame,
        nodes: pd.DataFrame,
        carbon: sim.CarbonSeries,
        network: sim.NetworkModel,
        speed_factors: dict[str, float],
        interval_seconds: float,
        maximum_reassignments_per_cycle: int,
        migration_volume_limit_gib: float,
        seed: int,
    ) -> None:
        required_tasks = {
            "dataset",
            "source_item_id",
            "nested_rank",
            "arrival_offset_s",
            "deadline_offset_s",
            "initial_region_id",
            "observed_cpu_work",
            "requested_cpu",
            "requested_memory",
            "migration_state_mib",
        }

        missing = (
            required_tasks
            - set(
                tasks.columns
            )
        )

        if missing:
            raise ValueError(
                f"Task columns missing: {sorted(missing)}"
            )

        self.tasks = tasks.sort_values(
            [
                "arrival_offset_s",
                "nested_rank",
                "source_item_id",
            ]
        ).reset_index(
            drop=True
        )

        self.nodes = nodes.sort_values(
            "node_id"
        ).reset_index(
            drop=True
        )

        self.carbon = carbon
        self.network = network

        self.speed_factors = {
            key: float(
                value
            )
            for key, value in speed_factors.items()
        }

        self.interval_seconds = float(
            interval_seconds
        )

        self.maximum_reassignments_per_cycle = int(
            maximum_reassignments_per_cycle
        )

        self.migration_volume_limit_gib = float(
            migration_volume_limit_gib
        )

        self.seed = int(
            seed
        )

        if self.interval_seconds <= 0:
            raise ValueError(
                "interval_seconds must be positive."
            )

        self.feasible_nodes = []

        for task in self.tasks.itertuples(
            index=False
        ):
            feasible = self.nodes.index[
                (
                    self.nodes[
                        "cpu_capacity"
                    ]
                    + 1e-9
                    >= float(
                        task.requested_cpu
                    )
                )
                & (
                    self.nodes[
                        "memory_capacity"
                    ]
                    + 1e-9
                    >= float(
                        task.requested_memory
                    )
                )
            ].to_numpy(
                dtype=int
            )

            if len(
                feasible
            ) == 0:
                raise RuntimeError(
                    f"No feasible node for task {task.source_item_id}."
                )

            self.feasible_nodes.append(
                feasible
            )

        self.state = self.tasks.copy()

        self.state[
            "current_node_index"
        ] = np.nan

        self.state[
            "data_ready_s"
        ] = self.state[
            "arrival_offset_s"
        ].astype(float)

        self.state[
            "accumulated_dispatch_delay_s"
        ] = 0.0

        self.state[
            "accumulated_migration_count"
        ] = 0

        self.state[
            "accumulated_migration_volume_gib"
        ] = 0.0

        self.state[
            "accumulated_migration_time_s"
        ] = 0.0

        self.state[
            "accumulated_migration_energy_wh"
        ] = 0.0

        self.state[
            "accumulated_migration_emissions_g"
        ] = 0.0

        self.state[
            "planned_start_s"
        ] = np.nan

        self.state[
            "planned_finish_s"
        ] = np.nan

        self.state[
            "committed_node_index"
        ] = np.nan

        self.state[
            "committed_start_s"
        ] = np.nan

        self.state[
            "committed_finish_s"
        ] = np.nan

        self.execution_records: list[
            dict
        ] = []

        self.cycle_records: list[
            dict
        ] = []

        self.migration_records: list[
            dict
        ] = []

        self.running_invariance_records: list[
            dict
        ] = []

    def _task_status_at(
        self,
        task_index: int,
        interval_start_s: float,
    ) -> str:
        row = self.state.iloc[
            task_index
        ]

        committed_start = row[
            "committed_start_s"
        ]

        committed_finish = row[
            "committed_finish_s"
        ]

        if (
            pd.notna(
                committed_finish
            )
            and float(
                committed_finish
            )
            <= interval_start_s
            + EPSILON
        ):
            return "completed"

        if (
            pd.notna(
                committed_start
            )
            and pd.notna(
                committed_finish
            )
            and float(
                committed_start
            )
            < interval_start_s
            - EPSILON
            and float(
                committed_finish
            )
            > interval_start_s
            + EPSILON
        ):
            return "running"

        if float(
            row[
                "arrival_offset_s"
            ]
        ) <= interval_start_s + EPSILON:
            return "pending"

        return "unseen"

    def status_frame(
        self,
        interval_start_s: float,
    ) -> pd.DataFrame:
        frame = self.state.copy()

        frame["status"] = [
            self._task_status_at(
                task_index,
                interval_start_s,
            )
            for task_index in range(
                len(
                    self.state
                )
            )
        ]

        return frame

    def _running_reservations(
        self,
        interval_start_s: float,
    ) -> dict[
        str,
        list[sim.Reservation],
    ]:
        reservations = {
            str(node_id): []
            for node_id in self.nodes[
                "node_id"
            ]
        }

        status = self.status_frame(
            interval_start_s
        )

        running = status[
            status[
                "status"
            ] == "running"
        ]

        for task_index, row in running.iterrows():
            node_index = int(
                row[
                    "committed_node_index"
                ]
            )

            node_id = str(
                self.nodes.iloc[
                    node_index
                ][
                    "node_id"
                ]
            )

            reservation = sim.Reservation(
                task_id=str(
                    row[
                        "source_item_id"
                    ]
                ),
                start_s=float(
                    row[
                        "committed_start_s"
                    ]
                ),
                finish_s=float(
                    row[
                        "committed_finish_s"
                    ]
                ),
                cpu=float(
                    row[
                        "requested_cpu"
                    ]
                ),
                memory=float(
                    row[
                        "requested_memory"
                    ]
                ),
            )

            reservations[
                node_id
            ].append(
                reservation
            )

        return reservations

    def _candidate_plan(
        self,
        task_index: int,
        node_index: int,
        interval_start_s: float,
        reservations: dict[
            str,
            list[sim.Reservation],
        ],
        is_new: bool,
        previous_node_index: int | None,
    ) -> PlannedPlacement:
        task = self.state.iloc[
            task_index
        ]

        node = self.nodes.iloc[
            int(
                node_index
            )
        ]

        runtime_s = sim.task_runtime_s(
            observed_cpu_work=float(
                task[
                    "observed_cpu_work"
                ]
            ),
            requested_cpu=float(
                task[
                    "requested_cpu"
                ]
            ),
            node_type=str(
                node[
                    "node_type"
                ]
            ),
            speed_factors=(
                self.speed_factors
            ),
        )

        destination_region = int(
            node[
                "region_id"
            ]
        )

        dispatch_delay_s = 0.0
        migration_count = 0
        migration_volume_gib = 0.0
        migration_time_s = 0.0
        migration_energy_wh = 0.0
        migration_emissions_g = 0.0

        transfer_start_s = max(
            float(
                task[
                    "arrival_offset_s"
                ]
            ),
            float(
                interval_start_s
            ),
            float(
                task[
                    "data_ready_s"
                ]
            ),
        )

        data_ready_s = float(
            task[
                "data_ready_s"
            ]
        )

        if is_new:
            source_region = int(
                task[
                    "initial_region_id"
                ]
            )

            dispatch_delay_s = (
                self.network.dispatch_delay_s(
                    source_region=source_region,
                    destination_region=(
                        destination_region
                    ),
                    key=(
                        f"{task['source_item_id']}|"
                        f"{node['node_id']}|initial"
                    ),
                    seed=self.seed,
                )
            )

        elif previous_node_index is not None:
            previous_region = int(
                self.nodes.iloc[
                    int(
                        previous_node_index
                    )
                ][
                    "region_id"
                ]
            )

            if (
                previous_region
                != destination_region
            ):
                migration = (
                    self.network.migration_cost(
                        source_region=(
                            previous_region
                        ),
                        destination_region=(
                            destination_region
                        ),
                        state_mib=float(
                            task[
                                "migration_state_mib"
                            ]
                        ),
                        time_s=float(
                            transfer_start_s
                        ),
                        carbon=self.carbon,
                        key=(
                            f"{task['source_item_id']}|"
                            f"{node['node_id']}|rolling"
                        ),
                        seed=self.seed,
                    )
                )

                migration_count = 1
                migration_volume_gib = (
                    float(
                        task[
                            "migration_state_mib"
                        ]
                    )
                    / 1024.0
                )

                migration_time_s = float(
                    migration[
                        "migration_time_s"
                    ]
                )

                migration_energy_wh = float(
                    migration[
                        "migration_energy_wh"
                    ]
                )

                migration_emissions_g = float(
                    migration[
                        "migration_emissions_g"
                    ]
                )

        if is_new:
            data_ready_s = (
                transfer_start_s
                + dispatch_delay_s
            )
        elif migration_count:
            data_ready_s = (
                transfer_start_s
                + migration_time_s
            )

        release_s = max(
            float(
                task[
                    "arrival_offset_s"
                ]
            ),
            float(
                interval_start_s
            ),
            float(
                data_ready_s
            ),
        )

        node_id = str(
            node[
                "node_id"
            ]
        )

        start_s = sim.earliest_feasible_start(
            reservations=(
                reservations[
                    node_id
                ]
            ),
            release_s=release_s,
            duration_s=runtime_s,
            demand_cpu=float(
                task[
                    "requested_cpu"
                ]
            ),
            demand_memory=float(
                task[
                    "requested_memory"
                ]
            ),
            cpu_capacity=float(
                node[
                    "cpu_capacity"
                ]
            ),
            memory_capacity=float(
                node[
                    "memory_capacity"
                ]
            ),
        )

        return PlannedPlacement(
            task_index=int(
                task_index
            ),
            node_index=int(
                node_index
            ),
            start_s=float(
                start_s
            ),
            finish_s=float(
                start_s
                + runtime_s
            ),
            runtime_s=float(
                runtime_s
            ),
            data_ready_s=float(
                data_ready_s
            ),
            dispatch_delay_s=float(
                dispatch_delay_s
            ),
            migration_count=int(
                migration_count
            ),
            migration_volume_gib=float(
                migration_volume_gib
            ),
            migration_time_s=float(
                migration_time_s
            ),
            migration_energy_wh=float(
                migration_energy_wh
            ),
            migration_emissions_g=float(
                migration_emissions_g
            ),
        )

    def _earliest_finish_plan(
        self,
        task_index: int,
        interval_start_s: float,
        reservations: dict[
            str,
            list[sim.Reservation],
        ],
        is_new: bool,
        previous_node_index: int | None,
    ) -> PlannedPlacement:
        candidates = [
            self._candidate_plan(
                task_index=task_index,
                node_index=int(
                    node_index
                ),
                interval_start_s=(
                    interval_start_s
                ),
                reservations=reservations,
                is_new=is_new,
                previous_node_index=(
                    previous_node_index
                ),
            )
            for node_index in self.feasible_nodes[
                task_index
            ]
        ]

        candidates.sort(
            key=lambda placement: (
                placement.finish_s,
                self.carbon.intensity(
                    int(
                        self.nodes.iloc[
                            placement.node_index
                        ][
                            "region_id"
                        ]
                    ),
                    placement.start_s,
                ),
                placement.migration_count,
                str(
                    self.nodes.iloc[
                        placement.node_index
                    ][
                        "node_id"
                    ]
                ),
            )
        )

        return candidates[
            0
        ]

    def run_cycle(
        self,
        cycle_index: int,
        interval_start_s: float,
        target_policy: Callable[
            [
                int,
                pd.Series,
                int | None,
                str,
                int,
            ],
            int | None,
        ],
    ) -> None:
        interval_end_s = (
            float(
                interval_start_s
            )
            + self.interval_seconds
        )

        status_start = self.status_frame(
            interval_start_s
        )

        running_start = status_start[
            status_start[
                "status"
            ] == "running"
        ].copy()

        completed_start = status_start[
            status_start[
                "status"
            ] == "completed"
        ]

        eligible_indices = []

        for task_index, row in self.state.iterrows():
            status = status_start.iloc[
                task_index
            ][
                "status"
            ]

            arrival = float(
                row[
                    "arrival_offset_s"
                ]
            )

            if (
                status
                not in {
                    "completed",
                    "running",
                }
                and arrival
                < interval_end_s
                - EPSILON
            ):
                eligible_indices.append(
                    int(
                        task_index
                    )
                )

        reservations = (
            self._running_reservations(
                interval_start_s
            )
        )

        previous_running_snapshot = {
            str(
                row[
                    "source_item_id"
                ]
            ): {
                "node_index": int(
                    row[
                        "committed_node_index"
                    ]
                ),
                "start_s": float(
                    row[
                        "committed_start_s"
                    ]
                ),
                "finish_s": float(
                    row[
                        "committed_finish_s"
                    ]
                ),
            }
            for _, row in running_start.iterrows()
        }

        dispatch_delay_s = 0.0
        migration_count = 0
        migration_volume_gib = 0.0
        migration_time_s = 0.0
        migration_energy_wh = 0.0
        migration_emissions_g = 0.0
        newly_seen_count = 0
        planned = []

        eligible_indices.sort(
            key=lambda index: (
                float(
                    self.state.iloc[
                        index
                    ][
                        "arrival_offset_s"
                    ]
                ),
                int(
                    self.state.iloc[
                        index
                    ][
                        "nested_rank"
                    ]
                ),
                str(
                    self.state.iloc[
                        index
                    ][
                        "source_item_id"
                    ]
                ),
            )
        )

        for task_index in eligible_indices:
            task = self.state.iloc[
                task_index
            ]

            previous_node = (
                None
                if pd.isna(
                    task[
                        "current_node_index"
                    ]
                )
                else int(
                    task[
                        "current_node_index"
                    ]
                )
            )

            is_new = (
                previous_node
                is None
            )

            if is_new:
                newly_seen_count += 1

            status_label = (
                "new"
                if is_new
                else "pending"
            )

            requested_target = target_policy(
                task_index,
                task.copy(),
                previous_node,
                status_label,
                int(
                    cycle_index
                ),
            )

            if (
                requested_target
                is not None
                and int(
                    requested_target
                )
                in self.feasible_nodes[
                    task_index
                ]
            ):
                candidate = self._candidate_plan(
                    task_index=task_index,
                    node_index=int(
                        requested_target
                    ),
                    interval_start_s=(
                        interval_start_s
                    ),
                    reservations=reservations,
                    is_new=is_new,
                    previous_node_index=(
                        previous_node
                    ),
                )
            elif (
                previous_node
                is not None
                and previous_node
                in self.feasible_nodes[
                    task_index
                ]
            ):
                candidate = self._candidate_plan(
                    task_index=task_index,
                    node_index=(
                        previous_node
                    ),
                    interval_start_s=(
                        interval_start_s
                    ),
                    reservations=reservations,
                    is_new=False,
                    previous_node_index=(
                        previous_node
                    ),
                )
            else:
                candidate = (
                    self._earliest_finish_plan(
                        task_index=task_index,
                        interval_start_s=(
                            interval_start_s
                        ),
                        reservations=reservations,
                        is_new=is_new,
                        previous_node_index=(
                            previous_node
                        ),
                    )
                )

            migration_allowed = (
                migration_count
                + candidate.migration_count
                <= self.maximum_reassignments_per_cycle
                and migration_volume_gib
                + candidate.migration_volume_gib
                <= self.migration_volume_limit_gib
                + EPSILON
            )

            if (
                candidate.migration_count
                and not migration_allowed
            ):
                candidate = self._candidate_plan(
                    task_index=task_index,
                    node_index=int(
                        previous_node
                    ),
                    interval_start_s=(
                        interval_start_s
                    ),
                    reservations=reservations,
                    is_new=False,
                    previous_node_index=(
                        previous_node
                    ),
                )

            node = self.nodes.iloc[
                candidate.node_index
            ]

            node_id = str(
                node[
                    "node_id"
                ]
            )

            reservation = sim.Reservation(
                task_id=str(
                    task[
                        "source_item_id"
                    ]
                ),
                start_s=(
                    candidate.start_s
                ),
                finish_s=(
                    candidate.finish_s
                ),
                cpu=float(
                    task[
                        "requested_cpu"
                    ]
                ),
                memory=float(
                    task[
                        "requested_memory"
                    ]
                ),
            )

            reservations[
                node_id
            ].append(
                reservation
            )

            reservations[
                node_id
            ].sort(
                key=lambda item: (
                    item.start_s,
                    item.finish_s,
                    item.task_id,
                )
            )

            self.state.at[
                task_index,
                "current_node_index",
            ] = (
                candidate.node_index
            )

            self.state.at[
                task_index,
                "data_ready_s",
            ] = (
                candidate.data_ready_s
            )

            if is_new:
                self.state.at[
                    task_index,
                    "accumulated_dispatch_delay_s",
                ] += (
                    candidate.dispatch_delay_s
                )

            if candidate.migration_count:
                self.state.at[
                    task_index,
                    "accumulated_migration_count",
                ] += (
                    candidate.migration_count
                )

                self.state.at[
                    task_index,
                    "accumulated_migration_volume_gib",
                ] += (
                    candidate.migration_volume_gib
                )

                self.state.at[
                    task_index,
                    "accumulated_migration_time_s",
                ] += (
                    candidate.migration_time_s
                )

                self.state.at[
                    task_index,
                    "accumulated_migration_energy_wh",
                ] += (
                    candidate.migration_energy_wh
                )

                self.state.at[
                    task_index,
                    "accumulated_migration_emissions_g",
                ] += (
                    candidate.migration_emissions_g
                )

            self.state.at[
                task_index,
                "planned_start_s",
            ] = (
                candidate.start_s
            )

            self.state.at[
                task_index,
                "planned_finish_s",
            ] = (
                candidate.finish_s
            )

            dispatch_delay_s += (
                candidate.dispatch_delay_s
            )

            migration_count += (
                candidate.migration_count
            )

            migration_volume_gib += (
                candidate.migration_volume_gib
            )

            migration_time_s += (
                candidate.migration_time_s
            )

            migration_energy_wh += (
                candidate.migration_energy_wh
            )

            migration_emissions_g += (
                candidate.migration_emissions_g
            )

            if candidate.migration_count:
                self.migration_records.append({
                    "cycle_index": int(
                        cycle_index
                    ),
                    "interval_start_s": float(
                        interval_start_s
                    ),
                    "source_item_id": str(
                        task[
                            "source_item_id"
                        ]
                    ),
                    "previous_node_index": int(
                        previous_node
                    ),
                    "new_node_index": int(
                        candidate.node_index
                    ),
                    "migration_volume_gib": (
                        candidate.migration_volume_gib
                    ),
                    "migration_time_s": (
                        candidate.migration_time_s
                    ),
                    "migration_energy_wh": (
                        candidate.migration_energy_wh
                    ),
                    "migration_emissions_g": (
                        candidate.migration_emissions_g
                    ),
                    "data_ready_s": (
                        candidate.data_ready_s
                    ),
                })

            planned.append(
                candidate
            )

        committed_count = 0

        for placement in planned:
            if (
                placement.start_s
                < interval_end_s
                - EPSILON
            ):
                task_index = (
                    placement.task_index
                )

                if pd.notna(
                    self.state.at[
                        task_index,
                        "committed_start_s",
                    ]
                ):
                    raise RuntimeError(
                        "A task was committed more than once."
                    )

                self.state.at[
                    task_index,
                    "committed_node_index",
                ] = (
                    placement.node_index
                )

                self.state.at[
                    task_index,
                    "committed_start_s",
                ] = (
                    placement.start_s
                )

                self.state.at[
                    task_index,
                    "committed_finish_s",
                ] = (
                    placement.finish_s
                )

                task = self.state.iloc[
                    task_index
                ]

                node = self.nodes.iloc[
                    placement.node_index
                ]

                self.execution_records.append({
                    "dataset": str(
                        task[
                            "dataset"
                        ]
                    ),
                    "source_item_id": str(
                        task[
                            "source_item_id"
                        ]
                    ),
                    "nested_rank": int(
                        task[
                            "nested_rank"
                        ]
                    ),
                    "cycle_committed": int(
                        cycle_index
                    ),
                    "arrival_offset_s": float(
                        task[
                            "arrival_offset_s"
                        ]
                    ),
                    "deadline_offset_s": float(
                        task[
                            "deadline_offset_s"
                        ]
                    ),
                    "node_index": int(
                        placement.node_index
                    ),
                    "node_id": str(
                        node[
                            "node_id"
                        ]
                    ),
                    "node_region_id": int(
                        node[
                            "region_id"
                        ]
                    ),
                    "node_type": str(
                        node[
                            "node_type"
                        ]
                    ),
                    "requested_cpu": float(
                        task[
                            "requested_cpu"
                        ]
                    ),
                    "requested_memory": float(
                        task[
                            "requested_memory"
                        ]
                    ),
                    "node_cpu_capacity": float(
                        node[
                            "cpu_capacity"
                        ]
                    ),
                    "node_memory_capacity": float(
                        node[
                            "memory_capacity"
                        ]
                    ),
                    "dispatch_delay_s": float(
                        task[
                            "accumulated_dispatch_delay_s"
                        ]
                    ),
                    "migration_count_at_commit": int(
                        task[
                            "accumulated_migration_count"
                        ]
                    ),
                    "migration_volume_gib_at_commit": float(
                        task[
                            "accumulated_migration_volume_gib"
                        ]
                    ),
                    "migration_time_s_at_commit": float(
                        task[
                            "accumulated_migration_time_s"
                        ]
                    ),
                    "migration_energy_wh_at_commit": float(
                        task[
                            "accumulated_migration_energy_wh"
                        ]
                    ),
                    "migration_emissions_g_at_commit": float(
                        task[
                            "accumulated_migration_emissions_g"
                        ]
                    ),
                    "data_ready_s": float(
                        task[
                            "data_ready_s"
                        ]
                    ),
                    "start_s": float(
                        placement.start_s
                    ),
                    "finish_s": float(
                        placement.finish_s
                    ),
                    "runtime_s": float(
                        placement.runtime_s
                    ),
                    "response_time_s": float(
                        placement.finish_s
                        - float(
                            task[
                                "arrival_offset_s"
                            ]
                        )
                    ),
                    "deadline_missed": bool(
                        placement.finish_s
                        > float(
                            task[
                                "deadline_offset_s"
                            ]
                        )
                        + EPSILON
                    ),
                })

                committed_count += 1

        status_end = self.status_frame(
            interval_end_s
        )

        for task_id, snapshot in previous_running_snapshot.items():
            row = self.state[
                self.state[
                    "source_item_id"
                ].astype(
                    str
                ) == task_id
            ].iloc[
                0
            ]

            invariant = (
                int(
                    row[
                        "committed_node_index"
                    ]
                )
                == snapshot[
                    "node_index"
                ]
                and math.isclose(
                    float(
                        row[
                            "committed_start_s"
                        ]
                    ),
                    snapshot[
                        "start_s"
                    ],
                    rel_tol=0.0,
                    abs_tol=EPSILON,
                )
                and math.isclose(
                    float(
                        row[
                            "committed_finish_s"
                        ]
                    ),
                    snapshot[
                        "finish_s"
                    ],
                    rel_tol=0.0,
                    abs_tol=EPSILON,
                )
            )

            self.running_invariance_records.append({
                "cycle_index": int(
                    cycle_index
                ),
                "source_item_id": (
                    task_id
                ),
                "invariant": bool(
                    invariant
                ),
            })

        self.cycle_records.append({
            "cycle_index": int(
                cycle_index
            ),
            "interval_start_s": float(
                interval_start_s
            ),
            "interval_end_s": float(
                interval_end_s
            ),
            "unseen_start": int(
                (
                    status_start[
                        "status"
                    ] == "unseen"
                ).sum()
            ),
            "pending_start": int(
                (
                    status_start[
                        "status"
                    ] == "pending"
                ).sum()
            ),
            "running_start": int(
                (
                    status_start[
                        "status"
                    ] == "running"
                ).sum()
            ),
            "completed_start": int(
                len(
                    completed_start
                )
            ),
            "eligible_count": int(
                len(
                    eligible_indices
                )
            ),
            "newly_seen_count": int(
                newly_seen_count
            ),
            "committed_count": int(
                committed_count
            ),
            "dispatch_delay_s": float(
                dispatch_delay_s
            ),
            "migration_count": int(
                migration_count
            ),
            "migration_volume_gib": float(
                migration_volume_gib
            ),
            "migration_time_s": float(
                migration_time_s
            ),
            "migration_energy_wh": float(
                migration_energy_wh
            ),
            "migration_emissions_g": float(
                migration_emissions_g
            ),
            "unseen_end": int(
                (
                    status_end[
                        "status"
                    ] == "unseen"
                ).sum()
            ),
            "pending_end": int(
                (
                    status_end[
                        "status"
                    ] == "pending"
                ).sum()
            ),
            "running_end": int(
                (
                    status_end[
                        "status"
                    ] == "running"
                ).sum()
            ),
            "completed_end": int(
                (
                    status_end[
                        "status"
                    ] == "completed"
                ).sum()
            ),
        })

    def run_until_complete(
        self,
        target_policy: Callable,
        maximum_cycles: int = 10000,
    ) -> dict[str, pd.DataFrame]:
        first_arrival = float(
            self.tasks[
                "arrival_offset_s"
            ].min()
        )

        start_time = (
            math.floor(
                first_arrival
                / self.interval_seconds
            )
            * self.interval_seconds
        )

        for cycle_index in range(
            int(
                maximum_cycles
            )
        ):
            interval_start_s = (
                start_time
                + cycle_index
                * self.interval_seconds
            )

            self.run_cycle(
                cycle_index=cycle_index,
                interval_start_s=(
                    interval_start_s
                ),
                target_policy=(
                    target_policy
                ),
            )

            status_end = self.status_frame(
                interval_start_s
                + self.interval_seconds
            )

            if (
                status_end[
                    "status"
                ] == "completed"
            ).all():
                break
        else:
            raise RuntimeError(
                "Rolling-horizon execution did not complete."
            )

        return {
            "task_state": (
                self.state.copy()
            ),
            "execution": pd.DataFrame(
                self.execution_records
            ),
            "cycles": pd.DataFrame(
                self.cycle_records
            ),
            "migrations": pd.DataFrame(
                self.migration_records
            ),
            "running_invariance": pd.DataFrame(
                self.running_invariance_records
            ),
        }


def stable_frame_hash(
    frame: pd.DataFrame,
) -> str:
    normalized = frame.copy()

    normalized = normalized.reindex(
        sorted(
            normalized.columns
        ),
        axis=1,
    )

    payload = normalized.to_csv(
        index=False,
        float_format="%.15g",
    ).encode(
        "utf-8"
    )

    return hashlib.sha256(
        payload
    ).hexdigest()
