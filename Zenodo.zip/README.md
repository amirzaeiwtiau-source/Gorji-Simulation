# H-CSMO — compact evidence and verification bundle (draft)

This compact bundle lets a reader independently verify the **140-run internal
ablation summary** from its frozen run-level results. It also supplies a
62-run completion inventory, a set of processed input references, and four
source modules whose SHA-256 fingerprints match the original run manifest.
It does **not** claim to reproduce all simulations from scratch.

## Verify the reported ablation summary

Requires Python 3.9+ (standard library only):

```bash
python3 tools/rebuild_ablation_from_frozen_runs.py --out reconstructed_ablation.csv
```

The command checks 140 `PASS` rows (2 datasets × 7 configurations × 10
seeds), recomputes means and sample standard deviations for eight recorded
metrics, and checks every value against the frozen summary. It does not
run any benchmark or change original result files. The output contains
14 rows and can be used as a source for an ablation table.

For statistical tests, consult the unchanged `140_wilcoxon_holm.csv`;
for Pareto counts, `140_pareto_nondominated.csv`. These are archived
statistics, not regenerated inferential results.

## Relationship to the paper

- `evidence/140_run_level.csv` and `evidence/140_group_reference.csv`:
  internal ablations, two frozen task workloads, 10 paired algorithm seeds.
- `evidence/140_wilcoxon_holm.csv`: paired inferential analysis for internal
  comparisons, with adjusted p-values.
- `evidence/140_pareto_nondominated.csv`: four-objective nondominance counts.
- `evidence/62_followup_index_derived.csv`: a **derived inventory** of 50
  sensitivity and 12 scale-out completed-run markers; detailed unchanged
  per-run files remain in the separate archival evidence package.
- `inputs/` and `config/`: processed reference workloads and infrastructure
  assumptions, **not independently verified byte-for-byte snapshots of
  every server-run input**.
- `code/`: four exact source modules with verified run-manifest SHA-256.

## Release qualification — outstanding

**Do not describe this bundle as full source-code reproducibility.** The
executed `hcsmo_rolling_coupled_v2.py` is required but is **not present**:
executed SHA-256 `cfa1c9a2cc4ed05ba8833d2cff1f000dac045b1193232ad6786de227da96ccc9`.
The accessible file with that name has a different hash and was purposely
excluded. It must be recovered from the original server before claiming
exact executable source coverage.

A full matched-version PPO/external-baseline comparison is **not verified**.
Do not combine or relabel the separate v6D benchmark as V2 results.

Raw data behind historical Figures 1–4 and Tables S3–S10, including the
2000-task Energy discrepancy between S7 and S8, has not been independently
traced to producing log files. The figure images alone are not raw provenance.

No Zenodo deposit, code DOI, license grant or release version is asserted
here. An author should verify the license and deposit the recovered exact
executed source, metadata and full requisite experiment inputs/results before
public DOI publication.

## File integrity

See `SHA256SUMS` for an integrity manifest of all bundled files.
This package contains no simulator execution or training output made in
response to a request for packaging.
